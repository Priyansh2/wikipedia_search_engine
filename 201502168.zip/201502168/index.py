#!/usr/bin/env python
# coding: utf-8

# In[85]:


import os
import re
import sys
import nltk
import string
import time
import threading
import xml.sax
from collections import defaultdict,Counter
from heapq import heappush, heappop
from nltk.stem.porter import PorterStemmer

FILES = 0 ## number of wiki_pages to be indexed at once (batch_processing)
FILE_CTR = 0 ## file offset in which partial index is stored
FILE_LIMIT = 1000 ## number of wiki pages to be indexed at once and then saved the posting list to file

DOCID_CTR = 0 ## docId which is mapped to title of wiki_page
DOCID_TITLE_MAP = None ## if not None, docID mapped to wiki title and mapping stored in the file

MAX_WORD_LEN = 10 ## word with length less than or equal to MAX_WORD_LEN is allowed
MIN_WORD_LEN = 3 ## word with length more than or equal to MIN_WORD_LEN is allowed
posting_list = defaultdict(lambda: defaultdict(int)) ## posting list which contain field information and docId corresponding to stemmed word


stop_words = set(['themselves', 'by', 'needn', "wasn't", 'now', 'to', 'why', 'of', 'then', 'after', "needn't",
				  "doesn't", 'all', 'didn', 'just', 'because', 't', 'they', 'most', 'isn', "isn't", 'doesn',
				  'your', 'ain', "shouldn't", 'into', 'and', 'both', 'haven', 'their', "weren't", 'will', 'as',
				  'i', "she's", 'were', "couldn't", 'itself', 'have', 'the', 'its', 'those', 'couldn', 'yours',
				  "mustn't", 'other', "you'll", 'been', 'he', 'don', 'shan', 'is', 'further', 'wasn', 'or',
				  'which', "should've", 'whom', 'does', 'an', 'o', "mightn't", "that'll", 'out', 'up', 'his',
				  'ours', 'so', "you've", 'her', "wouldn't", 'mightn', 'she', 'again', 'him', 'do', "hadn't",
				  'who', 'until', "you're", 'being', 'has', 'through', 'y', 'should', 'myself', 'there', 'with',
				  'what', 'be', 've', 'having', 'yourself', 'we', "didn't", 'hadn', 'had', 'll', 'doing', 'for',
				  'me', 'at', 'can', 'below', 'am', 'here', 'only', 'these', 'not', 'any', 'own', "it's",
				  'himself', 'm', 'a', 'no', 'wouldn', 's', 'won', 'under', 'each', 'them', 'against', 'some',
				  'same', 'in', 'aren', 'mustn', 'are', "you'd", 'about', "shan't", 'theirs', 'was', 'down', 'd',
				  'very', 'how', 'nor', 'ma', 'hasn', "hasn't", "aren't", 're', 'while', "don't", 'above',
				  'yourselves', 'if', 'more', 'hers', 'our', 'once', 'during', 'off', 'over', 'from', 'herself',
				  "won't", 'than', 'before', 'on', 'my', "haven't", 'few', 'between', 'when', 'ourselves', 'that',
				  'did', 'weren', 'too', 'this', 'you', 'shouldn', 'such', 'it', 'where', 'but'])

references_ignore = set(['reflist', 'colwidth', '30em', 'refs', 'ref', 'cite', 'name'])
extended_stopwords = set(list(stop_words)+list(references_ignore))
porter_stemmer = PorterStemmer() ## porter stemmer
camelcase_re = re.compile("([A-Z]+)")
ignore_re = re.compile("[-+*/!\"#$%&\'()=~|^@`\[\]{};:<>,.?_]")
body_re = re.compile("{{.*?}}|<.*?>", re.DOTALL)
url_re = re.compile('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+')
category_re = re.compile("Category:")


# In[86]:

def check_alphanumeric(word):
	## check if word contains only letters, numbers, underscores and dashes (alphanumeric string)
	if word.isalnum():
		return True
	return False
def check_alphabet(word):
	## check if word has all characters as alphabets
	if word.isalpha():
		return True
	return False

def is_english(s):
	try:
		s.encode(encoding='utf-8').decode('ascii')
	except UnicodeDecodeError:
		return False
	else:
		return True

def length_check(word):
	if len(word)>MIN_WORD_LEN and len(word)<MAX_WORD_LEN:
		return True
	return False


def custom_tokenizer(content):
	content = camelcase_re.sub(r' \1', content)
	content = ignore_re.sub(" ", content)
	content = content.replace("\\", " ")
	content = content.split()
	return content

def tokenizer(content):
	return custom_tokenizer(content)

def process_content(content,elem,docID,content_type="text"): ## content_type can be "text" or "url"
	tokens = tokenizer(content) ## tokenization
	if tokens and len(tokens[0].strip())>0:
		stop_word_list=stop_words
		if content_type=="url":
			stop_word_list=extended_stopwords
		for token in tokens:
			token = token.strip().lower()
			if token and token not in stop_word_list and is_english(token):
					posting_list_creation(token,elem,docID)


def posting_list_creation(word,elem,docId):
	## stemming the word of textual content present in "elem" field, to create posting list
	#if word:
	stemmed_word=porter_stemmer.stem(word)
	stemmed_word+=elem ## stemmed_word-field
	posting_list[stemmed_word][docId]+=1


# In[87]:


def write_to_file(end=False): ## create partial inverted_index files for handling memory and time issues
	global FILES, FILE_CTR, posting_list
	FILES += 1
	if end or FILES == FILE_LIMIT:
		FILES = 0
		if not os.path.exists("inverted_index"):
			os.makedirs("inverted_index")
		with open("inverted_index/file" + str(FILE_CTR), "w") as f:
			for x in sorted(posting_list):
				new_word = x + ";"
				temp = []
				for y in sorted(posting_list[x]):
					temp.append(y + ":" + str(posting_list[x][y]))
				new_word += ",".join(temp) ## Eg: stemmed_word-field;doc_id1:freq_w_in_doc1,doc_id2:freq_w_in_doc2. Here freq_w is freq. of stemmed word in field section of the document
				f.write(new_word + "\n")
		FILE_CTR += 1
		posting_list =defaultdict(lambda: defaultdict(int))

def merge_files(remove_index_files=False): ## merging inverted_index files using min_heap to create global index for searching
	index_files = []
	for x in range(FILE_CTR):
		index_files.append("inverted_index/file" + str(x))

	open_files = []
	index_heap = [] ## min_heap of index
	for file_ in index_files:
		open_files.append(open(file_,"r"))

	for file_ in open_files:
		line = file_.readline() ## read first line of every index file.
		word = line.split(";")[0] ## word here is: stemmed_word-field
		heappush(index_heap, (word, line, file_)) ## push 3-tuple: (word,line,file_) into empty heap

	while index_heap:
		smallest = heappop(index_heap)
		first_char = smallest[0][0]
		field = smallest[0].split('-')[1]

		if not os.path.exists(sys.argv[2]):
			os.makedirs(sys.argv[2])

		output_filename =os.path.join(sys.argv[2],'index'+'-'+first_char+'-'+field)
		with open(output_filename, "a") as f:
			f.write(smallest[1].replace("-" + field, ""))
		read_line = smallest[2].readline()## read next line of index file whose word is smallest (top-most lexicographically sorted word)

		if len(read_line) != 0: ## check if we arrived at end of file, if yes then pop out next smallest word
			word = read_line.split(";")[0]
			heappush(index_heap, (word, read_line, smallest[2]))

	[file_.close() for file_ in open_files]
	if remove_index_files:
		[os.remove(file_) for file_ in index_files]
		import shutil
		shutil.rmtree("inverted_index") ## remove the previously_created partial inverted_index files


# In[ ]:


def find_references(content):
	content = url_re.sub(" ", content)
	return content

def find_bodytext(content):
	content = body_re.sub(" ", content)
	content = url_re.sub(" ", content)
	return content

def find_urls(content):
	content = url_re.sub(" ", content)
	return content

def find_categories(content):
	content = category_re.sub(" ", content)
	return content

def get_time_info(sec_elapsed):
	h = int(sec_elapsed / (60 * 60))
	m = int((sec_elapsed % (60 * 60)) / 60)
	s = sec_elapsed % 60
	return "{}:{:>02}:{:>05.2f}".format(h, m, s)


# In[ ]:
duplicate_titles=defaultdict(int)

class WikiHandler(xml.sax.ContentHandler):
	def __init__(self):
		self.currElement = None ## to find starting tag
		self.innerElement = None ## to find fields like references, infobox, extlinks, category
		self.docId = None ## docId or wiki_page id/number which holds one-to-one mapping with wiki titles
		self.newLine = 0 ## newline counts. I used it to find external links
		self.title = "" ## to hold title (title buffer)
		self.references = "" ## to hold references (references buffer)
		self.body = "" ## to hold body text (bodytext buffer)
		self.links=""
		self.category=""
		self.infobox=""
		self.flag=1

	def startElement(self, name, attrs):
		self.currElement = name
		if self.currElement == "page": ## if start tag found is "page" which means it is starting of wiki article
			global DOCID_CTR, DOCID_TITLE_MAP

			if DOCID_CTR%1000==0: ## store the mapping between wiki page (doc_ID) ad title after processing 1000 pages.
				if DOCID_TITLE_MAP is not None: ## if DOCID_TITLE_MAP file is open then close it, else open it
					DOCID_TITLE_MAP.close()
				if not os.path.exists(sys.argv[2]):
					os.makedirs(sys.argv[2])
				DOCID_TITLE_MAP = open(os.path.join(sys.argv[2],"docid_title_map-" + str(int(DOCID_CTR/1000))), "w")
			self.docId = str(DOCID_CTR)
			DOCID_CTR += 1
			self.title = ""

		elif self.currElement == "text": ## is start tag found is "text"
			self.body = ""
			self.references = ""
			self.category=""
			self.infobox=""
			self.links=""
		self.innerElement = None ## when starting tag is found then at that time we dont have any inner content info like ref., outlinks, etc.

	def characters(self, content):
		if self.currElement == "title":
			#content=content.encode("ascii",errors="ignore").decode("ascii")
			content = content.encode("Windows-1254",errors="ignore").decode("Windows-1254")
			self.title += content ## write content into title buffer once title tag is found

		elif self.currElement == "text":
			#content=content.encode("ascii",errors="ignore").decode("ascii")
			content = content.encode("Windows-1254",errors="ignore").decode("Windows-1254")
			if self.innerElement is None: ## this means till now we dont know what content is among links, refs,cats, etc. So we search them.
				if "==External links==" in content or "== External links ==" in  content:
					self.innerElement = "externallinks" ## we found the content to be externallinks
				elif "{{Infobox" in content:
					self.innerElement = "infobox" ## we found the content to be infobox
				elif "Category:" in content:
					self.innerElement = "category"
					#process_content(find_categories(content), "-c", self.docId)
				elif "== References ==" in content or "==References==" in content:
					self.innerElement = "references"
				elif "#REDIRECT" not in content: ## ignore the text content which contains keyword #REDIRECT
					self.body += content

			elif self.innerElement=="category":
				self.category+=content

			elif self.innerElement == "externallinks":
				if content == "\n":
					self.newLine += 1
				else:
					self.newLine = 0
				if self.newLine == 2: ## if got two newlines that means we are done with externallinks
					self.newLine = 0
					self.innerElement = None
				self.links+=content
				#process_content(find_urls(content), "-e", self.docId)

			elif self.innerElement == "infobox":
				if content == "}}": ## if content is doubly closed curly braces then it means we are done with infobox
					self.innerElement = None
				elif content != "\n" and "=" in content:
					pos = content.index("=") ## find the position of "=" in content
					content = content[pos+1:] ## find the infomation in the box after "="
					self.infobox+=content
					#process_content(tokenizer(content), "-i", self.docId)

			elif self.innerElement == "references":
				if content == "\n":
					self.newLine += 1
				else:
					self.newLine = 0
				if self.newLine == 2:
					self.newLine = 0
					self.innerElement = None
				self.references += content

	def endElement(self, name):
		if self.currElement == "text":
			#global DOCID_CTR
			#if self.title.strip() and self.title.strip() not in duplicate_titles:
				#duplicate_titles[self.title.strip()]+=1
			process_content(find_bodytext(self.body.strip()), "-b", self.docId)
			process_content(find_categories(self.category.strip()), "-c", self.docId)
			process_content(find_urls(self.links.strip()), "-e", self.docId)
			process_content(self.infobox.strip(), "-i", self.docId)
			process_content(find_references(self.references.strip()), "-r", self.docId,content_type="url")
			process_content(self.title.strip(),"-t", self.docId)
			DOCID_TITLE_MAP.write(self.docId + ":" + self.title.strip() + "\n") ## Eg: docId:wiki_title
			write_to_file()
			#else:
				#DOCID_CTR+=-1



# In[ ]:

def main():
	#sys.argv[1]="enwiki_sample.xml"
	#sys.argv[2]="global"
	parser = xml.sax.make_parser()
	parser.setContentHandler(WikiHandler())
	parser.parse(open(sys.argv[1],"r"))
	write_to_file(True) ## to write partial index
	DOCID_TITLE_MAP.close()
	#for t in duplicate_titles:
		#if duplicate_titles[t]>1:
			#print(t,duplicate_titles[t],"\n")
	merge_files(True)
	with open("docid_ctr", "w") as f: ## stroing the docID counter (DOCID_CTR) value to file "docid_ctr"
		f.write(str(DOCID_CTR) + "\n")
	
if __name__ == '__main__':
    #start_time = time.time()
    main()
    #end_time = time.time()
    #elapsed_time = end_time - start_time
    #print("Elapsed time(sec):",elapsed_time)
    #print("Elapsed time(H:M:S): {}".format(get_time_info(elapsed_time)))



