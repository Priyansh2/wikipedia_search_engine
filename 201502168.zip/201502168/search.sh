python search.py $1 $2 $3
