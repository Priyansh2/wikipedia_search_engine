python index.py $1 $2
